
<a href="{{ route('add-building') }}">Add New</a>

{{ Form::open() }}

@foreach($buildings as $building)

	<li>{{ Form::checkbox('ch[]' , $building->id, false) }}<a href="{{ route('view-item-building' , $building->id) }}">{{ $building->building_name }}</a> <a href="{{ route('show-building' , $building->id) }}">Edit</a> | <a href="{{ route('delete-building' , $building->id) }}">Delete</a></li>

@endforeach

{{ Form::submit('delete') }}

{{ Form::close() }}
