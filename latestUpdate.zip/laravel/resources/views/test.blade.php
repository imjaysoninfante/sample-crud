<?php
/*$url = 'https://www.oneflare.com.au/b/mr-tax-refund-953#reviewAnchor';

$contents = file_get_contents($url);

echo $contents;*/

/*if ($stream = fopen('https://www.oneflare.com.au/b/mr-tax-refund-953#reviewAnchor', 'r')) {
    // print all the page starting at the offset 10
    echo stream_get_contents($stream, -1, 10);

    fclose($stream);
}*/

$url = 'https://www.oneflare.com.au/b/mr-tax-refund-953#reviewAnchor';
$content = file_get_contents($url);
$first_step = explode( '<div class="public-profile">' , $content );
$second_step = explode("</div>" , $first_step[1] );

echo $second_step[0];