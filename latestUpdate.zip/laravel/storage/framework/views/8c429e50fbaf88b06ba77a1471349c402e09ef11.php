
<a href="<?php echo e(route('add-building')); ?>">Add New</a>

<?php echo e(Form::model($building, ['method' => 'PATCH' , 'route' => ['show-building' , $building->id]])); ?>


	<?php echo e(Form::label('building_name')); ?>


	<?php echo e(Form::text('building_name')); ?>


	<?php echo e(Form::submit('Update')); ?>


<?php echo e(Form::close()); ?>