
<a href="<?php echo e(route('add-building')); ?>">Add New</a>

<?php echo e(Form::open()); ?>


<?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<li><?php echo e(Form::checkbox('ch[]' , $building->id, false)); ?><a href="<?php echo e(route('view-item-building' , $building->id)); ?>"><?php echo e($building->building_name); ?></a> <a href="<?php echo e(route('show-building' , $building->id)); ?>">Edit</a> | <a href="<?php echo e(route('delete-building' , $building->id)); ?>">Delete</a></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e(Form::submit('delete')); ?>


<?php echo e(Form::close()); ?>

