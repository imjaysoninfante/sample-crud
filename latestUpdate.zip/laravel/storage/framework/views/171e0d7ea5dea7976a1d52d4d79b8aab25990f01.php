<?php echo e($buildings->id); ?>


<?php echo e($buildings->building_name); ?>


<?php echo e($buildings->created_at); ?>