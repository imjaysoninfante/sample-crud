{{ Form::open(array('files' => 'true')) }}
{{ Form::label('file') }}

{{ Form::text('file_name') }}

{{ Form::file('upload') }}

{{ Form::submit('Upload') }}

{{ Form::close() }}


@foreach($uploads as $upload)

	<li>{{ Html::image($upload->image_destination) }} <a href="{{ route('delete-file' , $upload->id) }}">Delete File</a></li>

@endforeach()