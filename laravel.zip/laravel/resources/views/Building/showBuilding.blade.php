
<a href="{{ route('add-building') }}">Add New</a>

{{ Form::model($building, ['method' => 'PATCH' , 'route' => ['show-building' , $building->id]]) }}

	{{ Form::label('building_name') }}

	{{ Form::text('building_name') }}

	{{ Form::submit('Update') }}

{{ Form::close() }}
<a href="{{ route('view-building') }}">Building</a>