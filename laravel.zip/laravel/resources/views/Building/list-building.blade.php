
<a href="{{ route('add-building') }}">Add New</a>

@foreach($buildings as $building)

	<li>{{ $building->building_name }} <a href="{{ route('show-building' , $building->id) }}">Edit</a> | <a href="{{ route('delete-building' , $building->id) }}">Delete</a></li>

@endforeach