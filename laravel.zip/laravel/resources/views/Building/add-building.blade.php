{{ Form:: open() }}

	{{ Form::label('building_name') }}

	{{ Form::text('building_name') }}

	{{ Form::submit('Save') }}

{{ Form::close() }}