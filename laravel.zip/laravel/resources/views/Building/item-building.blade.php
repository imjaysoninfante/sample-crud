{{ $buildings->id }}

{{ $buildings->building_name }}

{{ $buildings->created_at }}