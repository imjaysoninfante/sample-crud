<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Upload;
use Illuminate\Support\Facades\Input;



class uploadController extends Controller
{
    //

    public function getForm(){

    	$uploads = Upload::all();

    	return View('Uploading.uploading')
    	->with('uploads' , $uploads);
    }

    public function uploadFile(){

    	$destination = 'assets/img/';

    	$file = Input::file('upload');

    	$data = $file->getClientOriginalName();

    	$resource = $file->move($destination , $data);

    	$data = array(

    		    'image_name' => Input::get('file_name'),

    			'image_destination' => $resource
    		);
   
    	Upload::create($data);


    }
}
