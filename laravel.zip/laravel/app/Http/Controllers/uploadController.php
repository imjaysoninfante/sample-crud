<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Upload;
use File;
use Illuminate\Support\Facades\Input;



class uploadController extends Controller
{
    //

    public function getForm(){

    	$uploads = Upload::all();

    	return View('Uploading.uploading')
    	->with('uploads' , $uploads);
    }

    public function uploadFile(){

        $y = date('Y');

        $m = date('m');
        
        $file = Input::file('upload');
        
        $destination = 'assets/img/'.$y.'/'.$m.'/';
        
        $data = $file->getClientOriginalName();

    	$resource = $file->move($destination , $data);

    	$dataArray = array(

    		    'image_name' => Input::get('file_name'),

    			'image_destination' => $resource
    		);

    	Upload::create($dataArray);
       

    }

    public function deleteFileFromFolder($id){
       
        $deleteFile = Upload::find($id);

        $fileToDelete = $deleteFile->image_destination;

        $fh = fopen($fileToDelete, 'a');
       
        fwrite($fh, '<h1>File Ready to Delete</h1>');
       
        fclose($fh);

        unlink($fileToDelete);

        $deleteFile->delete();
    }
}
