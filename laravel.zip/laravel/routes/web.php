<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/buildings/' , ['uses' => 'BuildingController@getBuilding' , 'as' => 'view-building']);
Route::get('/add/building/' , ['uses' => 'BuildingController@addBuilding' , 'as' => 'add-building']);
Route::post('/add/building' , ['uses' => 'BuildingController@insertBuildingInfo']);
Route::get('/show/{id}/building/' , ['uses' => 'BuildingController@showBuilding' , 'as' => 'show-building']);
Route::get('/delete/{id}/building/' , ['uses' => 'BuildingController@deleteBuilding' , 'as' => 'delete-building']);
Route::patch('/show/{id}/building/' , ['uses' => 'BuildingController@updateBuilding' , 'as' =>'update-building']);
Route::get('/view/{id}/building/' , ['uses' => 'BuildingController@viewItemBuilding' , 'as' => 'view-item-building']);
Route::post('/buildings/' , ['uses' => 'BuildingController@deleteAll' , 'as' => 'deleteAll']);

Route::get('test' , ['uses' => 'BuildingController@getTest']);


Route::get('/upload' , ['uses' => 'uploadController@getForm' ,]);
Route::post('/upload' , ['uses' => 'uploadController@uploadFile' , 'as' => 'upload']);

ROUTE::GET('/deleteFile/{id}/photo' , ['uses' => 'uploadController@deleteFileFromFolder' , 'as' => 'delete-file']);