<?php echo e(Form::open(array('files' => 'true'))); ?>

<?php echo e(Form::label('file')); ?>


<?php echo e(Form::text('file_name')); ?>


<?php echo e(Form::file('upload')); ?>


<?php echo e(Form::submit('Upload')); ?>


<?php echo e(Form::close()); ?>



<?php $__currentLoopData = $uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<li><?php echo e(Html::image($upload->image_destination)); ?></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>