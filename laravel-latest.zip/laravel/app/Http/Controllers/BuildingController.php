<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

use Validator;
use App\Building;
use DB;
class BuildingController extends Controller
{
    //

    public function getBuilding(){

    	$buildings = Building::all();

    	return View('Building.list-building')
    	->withBuildings($buildings);
    }

    public function addBuilding(){
    	return View('Building.add-building');
    }

    public function insertBuildingInfo(){

    	$rules = [

    		'building_name' => 'required'

    	];

    	$validator = Validator::make(Input::all() , $rules);

    	if($validator->fails()){
    		return 'failed';
    	}
    	else{
    		
    		$data = [

    			'building_name' => Input::get('building_name')
    		];

    		Building::create($data);

    		$id = DB::table('buildings')->insertGetId( $data );
    		
    		return redirect('/show/' . $id . '/building/');

    	}

    }

    public function showBuilding($id){

    		$building = Building::find($id);

    		return View('Building.showBuilding')
    		->with('building' , $building);



    }

    public function deleteBuilding($id){

    	$building = Building::find($id);

    	$building->delete();

    	return redirect('/buildings');

    }


    public function updateBuilding($id){

    	$building = Building::find($id);

    	$input = Input::all();

    	$building->fill($input)->save();

    	return redirect('/buildings');
    }

}
