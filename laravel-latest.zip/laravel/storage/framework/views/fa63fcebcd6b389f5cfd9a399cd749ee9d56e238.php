
<a href="<?php echo e(route('add-building')); ?>">Add New</a>

<?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<li><?php echo e($building->building_name); ?> <a href="<?php echo e(route('show-building' , $building->id)); ?>">Edit</a> | <a href="<?php echo e(route('delete-building' , $building->id)); ?>">Delete</a></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!DOCTYPE HTML>
<html>

<head>  

	<script src="http://canvasjs.com/assets/script/canvasjs.min.js"></script>
  <script type="text/javascript">
  window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer",
    {      
      theme:"theme2",
      title:{
        text: "Reports"
      },
      animationEnabled: true,
      axisY :{
        includeZero: false,
        // suffix: " k",
        valueFormatString: "#,,.",
        suffix: " mm"
        
      },
      toolTip: {
        shared: "true"
      },
      data: [
      {        
        type: "spline", 
        showInLegend: true,
        name: "Target Income",
        // markerSize: 0,        
        // color: "rgba(54,158,173,.6)",
        dataPoints: [
        {label: "January.2017", y: 2220000},
        {label: "February.2017", y: 2240000},        
        {label: "March.2017", y: 2280000},        
        {label: "April.2017", y: 2310000},        
        {label: "May.2017", y: 2320000},        
        {label: "June.2017", y: 2420000},        
        {label: "July.2017", y: 2520000},        
        {label: "August.2017", y: 2620000},        
        {label: "September.2017", y: 2720000},        
        {label: "October.2017", y: 2820000},
        {label: "November.2017", y: 2920000},
        {label: "December.2017", y: 3220000}


        ]
      },
      {        
        type: "spline", 
        showInLegend: true,
        // markerSize: 0,
        name: "Actual Income",
        dataPoints: [
         {label: "January.2017", y: 2220000},
         
        ]
      } 
      

      ],
      legend:{
        cursor:"pointer",
        itemclick : function(e) {
          if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible ){
          	e.dataSeries.visible = false;
          }
          else {
            e.dataSeries.visible = true;
          }
          chart.render();
        }
        
      },
    });

chart.render();
}
</script>
</head>
<body>
  <div id="chartContainer" style="height: 300px; width: 100%;">
  </div>
</body>
</html>
