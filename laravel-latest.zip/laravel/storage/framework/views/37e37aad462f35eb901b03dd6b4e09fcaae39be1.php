<?php echo e(Form:: open()); ?>


	<?php echo e(Form::label('building_name')); ?>


	<?php echo e(Form::text('building_name')); ?>


	<?php echo e(Form::submit('Save')); ?>


<?php echo e(Form::close()); ?>